package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        private Spinner spinner;
        private EditText H,g;
        private TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner=findViewById(R.id.spinner);
        H=findViewById(R.id.H);
        g=findViewById(R.id.g);
        tv1=findViewById(R.id.tv1);
        String[] options={"calculer x0", "soustraction", "multiplication", "division"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,options);
        spinner.setAdapter(adapter);
    }

    public void button(View view) {
        String v1 = H.getText().toString();
        String v2 = g.getText().toString();
        int nbo1 = Integer.parseInt(v1);
        int nbo2 = Integer.parseInt(v2);
        String select = spinner.getSelectedItem().toString();

        if (select.equals("calculer x0")){
            int somme=-nbo2*(1/(2*2))+1+20;
            String resultat = String.valueOf(somme);
            tv1.setText("le resultat est " + resultat);
        }else
            if (select.equals("soustraction")){
                int soust=nbo1-nbo2;
                String resultat = String.valueOf(soust);
                tv1.setText(resultat);
            }else
                if (select.equals("multiplication")){
                    int multi=nbo1*nbo2;
                    String resultat = String.valueOf(multi);
                    tv1.setText(resultat);
                }else
                    if (select.equals("division")){
                            int div=nbo1-nbo2;
                            String resultat = String.valueOf(div);
                            tv1.setText(resultat);
                    }
    }
}