package com.example.tp4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        private Spinner spinner;
        private EditText Y0,alpha,v0,g,T,x;
        private TextView tv1,tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner=findViewById(R.id.spinner);
        Y0=findViewById(R.id.Y0);
        g=findViewById(R.id.g);
        T=findViewById(R.id.T);
        alpha=findViewById(R.id.alpha);
        x=findViewById(R.id.x);
        v0=findViewById(R.id.v0);
        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);
        String[] options={"calculer x0"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,options);
        spinner.setAdapter(adapter);
    }

    public void button(View view) {
        String v1 = Y0.getText().toString();
        String v2 = alpha.getText().toString();
        String v3 = v0.getText().toString();
        String v4 = g.getText().toString();
        String v5 = T.getText().toString();
        String v6 = x.getText().toString();
        int Y0 = Integer.parseInt(v1);
        int v0 = Integer.parseInt(v3);
        double g = Double.parseDouble(v4);
        double T = Double.parseDouble(v5);
        double alpha = Double.parseDouble(v2);
        double radian = Math.toRadians(alpha);
        double x = Double.parseDouble(v6);;
        double cosa = Math.cos(alpha);
        double t = x/(v0*cosa);
        double sina = Math.sin(alpha);
        double tana = Math.cos(alpha);
        double X = (v0*cosa)*T;
        double Y = -(1/2)*g*t*t+v0*sina*t+Y0;
        double Yx = -(1/2)*g*((x/(v0*cosa))*(x/(v0*cosa)))+x*tana+Y0;
        String select = spinner.getSelectedItem().toString();

        // -g.(x²/(2.v0².cos²alpha))+tan alpha =0



        if (select.equals("calculer x0")){


            String resultat = String.valueOf(Yx);
            tv1.setText("y("+T+") = " + Y +" et x("+T+") = " + x);
            tv2.setText("l'equation horaire est : " + Yx);



        }
    }
}